--Q4)
data Polynomial a = Coeff a Int (Polynomial a)| Null deriving Show 

--4a)

foldPoly::(a -> Int-> b-> b)-> b -> Polynomial a -> b
foldPoly f e Null = e
foldPoly f e (Coeff c n p) = f c n (foldPoly f e p)

--4b)

degree:: Polynomial Int -> Int
degree Null = minBound::Int
degree (Coeff c n p) = foldl (\x acc -> if (x>acc) then x else acc) 0 (foldPoly f e (Coeff c n p))
 where f = \c n m -> n:m
       e = []