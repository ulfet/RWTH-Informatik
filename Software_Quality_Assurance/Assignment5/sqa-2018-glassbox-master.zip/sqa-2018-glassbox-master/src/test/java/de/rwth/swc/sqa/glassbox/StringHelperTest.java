package de.rwth.swc.sqa.glassbox;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class StringHelperTest {

    @Test
    void demonstrationTest() {
        assertEquals( "abc  ", StringHelper.stripFromStart("yxabc  ", "xyz"));
    }
}
