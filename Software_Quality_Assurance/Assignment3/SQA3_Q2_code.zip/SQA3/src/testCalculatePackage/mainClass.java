package testCalculatePackage;
public class mainClass {
	public static void main(String [] args) {
		calculatePriceClass cp=new calculatePriceClass();
		//(ProductType type, double weight, int zone, double dimension, paymentMethod pm, int quantity)
		
		
		//System.out.println(cp.calculatePrice(ProductType.pXS, 1, 0, 75, paymentMethod.online, 10));
		System.out.println(cp.calculatePrice(ProductType.pXS, 10, 0, 47, paymentMethod.online, 10));	
		System.out.println(cp.calculatePrice(ProductType.pXS, 10, 0, 47, paymentMethod.online, 77));	
		System.out.println(cp.calculatePrice(ProductType.pXS, 10, 0, 47, paymentMethod.shop, 10));
		System.out.println(cp.calculatePrice(ProductType.pXS, 10, 0, 250, paymentMethod.online, 10));
		System.out.println(cp.calculatePrice(ProductType.pXS, 111, 0, 47, paymentMethod.online, 10));
		System.out.println(cp.calculatePrice(ProductType.pXS, 10, -1, 47, paymentMethod.online, 10));
		
		
	
	}
}
