package testCalculatePackage;

public class calculatePriceClass {

	public double calculatePrice(ProductType type, double weight, int zone, double dimension, paymentMethod pm, int quantity)
	{
		double price=1.0;
		double pricePerUnit=0.0;
		double total=0.0;
		if( quantity <0 || quantity%10!=0 || quantity>50)
			return -1;
		if( dimension <0 || dimension>240)
			return -1;
		if( zone <0 || zone>8)
			return -1;
		if( weight <0 || weight>31.5)
			return -1;
		
		switch(type) {
		case pXS:
			if(pm == paymentMethod.online)
				pricePerUnit=3.89;
			else
				pricePerUnit=4.0;
			break;
		case pS:
			if(pm == paymentMethod.online)
				pricePerUnit=4.39;
			else
				pricePerUnit=4.5;
			break;
		case s:
			if(pm == paymentMethod.online)
				pricePerUnit=4.99;
			else
				pricePerUnit=0;
			break;
		case m:
			if(pm == paymentMethod.online)
				pricePerUnit=5.99;
			else
				pricePerUnit=6.99;
			break;
		case l:
			if(pm == paymentMethod.online)
				pricePerUnit=8.49;
			else
				pricePerUnit=9.49;
			break;
		case xl:
			pricePerUnit=16.49;
			break;
		case rgp:
			pricePerUnit=16.49;
			break;
		default: pricePerUnit=-1.0;
		}
		
		
		price=weight*(zone+1)*dimension*quantity;
		total=(price*pricePerUnit)/100;
		
		if(total>10 && pm == paymentMethod.shop)
			return total+9.99;
		return total;
	}
}
