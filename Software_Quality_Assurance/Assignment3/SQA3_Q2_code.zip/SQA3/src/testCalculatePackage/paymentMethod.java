package testCalculatePackage;

public enum paymentMethod {
online, shop;
}
