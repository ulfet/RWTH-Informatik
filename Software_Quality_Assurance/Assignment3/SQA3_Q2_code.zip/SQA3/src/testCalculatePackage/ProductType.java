package testCalculatePackage;

public enum ProductType {
 pXS,pS,s,m,l,xl,rgp;
}
