package testCalculatePackage;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class calculatePriceTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	void test() {
		calculatePriceClass cpc=new calculatePriceClass();
		try {
			
		assertEquals(182.83, cpc.calculatePrice(ProductType.pXS, 10, 0, 47, paymentMethod.online, 10));
		assertEquals(-1, cpc.calculatePrice(ProductType.pXS, 10, 0, 47, paymentMethod.online, 77));
		//assertEquals(-1, cpc.calculatePrice(ProductType.pXS, 10, 0, 47, paymentMethod.shop, 10)); 
		//We cannot accept any other value for ProductType and PaymentMethod than those mentioned in the enum classes
		assertEquals(-1, cpc.calculatePrice(ProductType.pXS, 10, 0, 250, paymentMethod.online, 10));	
		assertEquals(-1, cpc.calculatePrice(ProductType.pXS, 111, 0, 47, paymentMethod.online, 10));
		assertEquals(-1, cpc.calculatePrice(ProductType.pXS, 10, -1, 47, paymentMethod.online, 10));
			
		}
		catch(Exception e) 
		{
			assertEquals(-1,-1);
		}
	}

}
