package de.rwth.swc.teaching.sqa.vendingmachine;

import de.rwth.swc.teaching.sqa.Drink;
import de.rwth.swc.teaching.sqa.VendingMachine;
import de.rwth.swc.teaching.sqa.exception.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;


public class VendingMachineTest {

    private VendingMachine machine;

    @BeforeAll
    public void init() throws InvalidDrinkNumberException {
        this.machine =  new VendingMachine(1,0,0);

    }

    @Test
    public void testGetOneCoke() throws InvalidDrinkException, CoinInsertedException, MachineEmptyException, NoCoinInsertedException {
            machine.insertCoin();
            Assertions.assertTrue(machine.coinInserted());
            machine.getDrink(Drink.COKE);
            Assertions.assertTrue(machine.drinkEmpty(Drink.COKE));
    }

    @Test
    public void testGetOneCokeWithoutCoint() throws InvalidDrinkException, CoinInsertedException, MachineEmptyException, NoCoinInsertedException {
        Assertions.assertFalse(machine.coinInserted());
        Executable executeGetDringForCoke = () -> machine.getDrink(Drink.COKE);
        Assertions.assertThrows(NoCoinInsertedException.class, executeGetDringForCoke);
    }


}
