package de.rwth.swc.teaching.sqa.exception;

public class MachineEmptyException extends Exception {
}
