package de.rwth.swc.teaching.sqa.exception;

public class NoCoinInsertedException extends Exception{
}
