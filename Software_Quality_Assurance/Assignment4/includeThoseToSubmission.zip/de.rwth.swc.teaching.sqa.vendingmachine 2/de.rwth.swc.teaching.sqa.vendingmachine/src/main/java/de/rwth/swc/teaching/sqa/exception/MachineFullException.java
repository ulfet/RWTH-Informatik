package de.rwth.swc.teaching.sqa.exception;

public class MachineFullException extends Exception {
}
