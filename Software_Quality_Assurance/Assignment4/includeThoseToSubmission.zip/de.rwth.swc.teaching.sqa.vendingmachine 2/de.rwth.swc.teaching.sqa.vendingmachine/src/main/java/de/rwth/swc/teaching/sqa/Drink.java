package de.rwth.swc.teaching.sqa;

public enum Drink {

    COKE("Coke"),LEMONADE("Lemonade"),WATER("Water");

    private final String name;

    Drink(String name) {
        this.name = name;
    }
}
