package de.rwth.swc.teaching.sqa.exception;

public class InvalidDrinkNumberException extends Exception{
}
